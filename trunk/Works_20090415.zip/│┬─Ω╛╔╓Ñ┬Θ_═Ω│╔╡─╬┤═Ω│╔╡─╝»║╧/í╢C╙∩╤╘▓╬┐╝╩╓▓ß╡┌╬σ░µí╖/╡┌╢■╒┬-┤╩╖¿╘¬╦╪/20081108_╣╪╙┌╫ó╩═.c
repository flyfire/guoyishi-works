#include <stdio.h>
void main()
{
	int a,b;
	printf("this /*mom*/ ok?\n");
}
