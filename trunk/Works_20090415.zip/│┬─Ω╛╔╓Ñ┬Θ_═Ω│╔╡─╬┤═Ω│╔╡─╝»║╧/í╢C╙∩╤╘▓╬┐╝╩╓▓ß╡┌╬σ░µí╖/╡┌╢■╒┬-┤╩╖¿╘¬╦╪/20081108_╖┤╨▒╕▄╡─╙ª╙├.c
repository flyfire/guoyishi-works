#include <stdio.h>
void main()
{
	int a,b;
	a=2;b=4;
	if(a==4)
	{
	printf("\n\n1111111111\n");
	printf("\n22222\n");
	}
		else
	{
		printf("\n333333333\n");
	}

}
