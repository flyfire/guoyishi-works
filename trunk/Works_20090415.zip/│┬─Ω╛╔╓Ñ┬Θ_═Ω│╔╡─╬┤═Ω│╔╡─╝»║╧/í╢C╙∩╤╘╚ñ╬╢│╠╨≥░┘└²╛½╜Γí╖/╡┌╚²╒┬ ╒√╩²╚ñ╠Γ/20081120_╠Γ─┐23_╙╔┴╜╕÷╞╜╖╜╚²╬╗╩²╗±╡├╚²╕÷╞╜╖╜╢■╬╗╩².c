#include <stdio.h>
void main(void)
{
	int a,b,c,x,y,z;
	int m,n;
	for()
}
