#include <stdio.h>
void main(void)
{
	int i;
	float x=0;
	for(i=0;i<5;i++)
	{
		x=(x+1000)/(1+12*.0063);
	}
	printf("��һ��Ӧ�ô�%.2fԪǮ\n",x);
}