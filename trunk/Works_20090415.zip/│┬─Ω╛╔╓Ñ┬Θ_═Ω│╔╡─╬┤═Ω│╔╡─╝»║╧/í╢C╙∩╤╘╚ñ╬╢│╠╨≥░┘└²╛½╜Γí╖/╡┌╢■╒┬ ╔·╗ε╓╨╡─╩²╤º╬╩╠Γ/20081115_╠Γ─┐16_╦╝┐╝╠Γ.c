#include <stdio.h>
void main(void)
{
	int i,m;
	float s1,s2,s3,s4,s5,s6;
	float k=8.0;
	printf("===�ֵֽܷ���===\n");
	for(s1=8;flag;s1+=8)
	{
		s1=s1*(1-1/k);
		for(s2=1;falg;s2++)
		{
			s2=s2+s1/k;
			k--;
			s2=s2*(1-1/k);
			for(s3=1;flag;s3++)
			{
				s3=s3+s2/k;
				k--;
				s3=s3*()
			}
		}
	}
}