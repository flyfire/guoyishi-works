#include <stdio.h>

int main()
{
	int a1,a2,a3,a4;
	int z1,z2;
	for(a1=1;a1<=4;a1++)
		for(z1=5;z1<=9;z1++)
			for(a2=0;a2<=4;a2++)
				for(z2=5;z2<=9;z2++)
				{
					m=100*a1+10*z1+a2;
					if(m*z2==)
				}
}
//Unfinished