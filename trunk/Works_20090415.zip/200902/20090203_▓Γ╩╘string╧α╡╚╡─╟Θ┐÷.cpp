#include <iostream>
#include <string>
using namespace std;

int main()
{
	string s;
	cin >> s;
	if(s == "meiyou")	//Have " "
		cout << "meiyou" << endl;

	return 0;
}