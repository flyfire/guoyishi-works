#include <iostream>
using namespace std;

int main()
{
	cout << "true: " << true << endl;
	cout << "false: " << false << endl;
	cout << boolalpha;
	cout << "true: " << true << endl;
	cout << "false: " << false << endl;
	cout << noboolalpha;
	cout << "true: " << true << endl;
	cout << "false: " << false << endl;

	return 0;
}