#include <iostream>

int main()
{
	std::cout << 'N'<< "NNNNee" << 'd' << 'o'   << std::endl;

	return 0;
}