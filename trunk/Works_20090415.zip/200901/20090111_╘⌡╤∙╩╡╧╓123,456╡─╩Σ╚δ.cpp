#include <iostream>

int main()
{
	int v1,v2;

	std::cout << "Input two numbers:" << std::endl;
	std::cin >> v1 >> v2 ;
	std::cout << v1 << " + " << v2 << " is " << v1+v2 << std::endl;

	return 0;
}
