#include <iostream>
#include <string>
using namespace std;

int main()
{
	string word;
	while(cin >> word)
		cout << word << endl;

	return 0;
}