class X {
	int i;
	int j;
public:
	X(int val): j(val), i(j) {}
};

int main()
{
	return 0;
}