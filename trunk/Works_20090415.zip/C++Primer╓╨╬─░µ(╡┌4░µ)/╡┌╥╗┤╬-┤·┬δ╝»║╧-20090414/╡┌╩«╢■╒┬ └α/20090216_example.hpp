#include <vector>
#include <iostream>
using namespace std;

class Example {
public:
	static double rate;
	static const int vecSize = 20;
	static vector<double> vec;
};