class C {
public:
	C(): noDeObj(10) {}
	//...
private:
	NoDefault noDeObj;
	//...
}