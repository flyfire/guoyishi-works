class Bar {
private:
	static int ival;
	static Foo fval;
};