#include <iostream>
using namespace std;

int main()
{
	cout << "-30*3+21/5" << "=" << -30*3+21/5 << endl;
	cout << "-30+3*21/5" << "=" << -30+3*21/5 << endl;
	cout << "30/3*21%5"  << "=" << 30/3*21%5  << endl;
	cout << "-30/3*21%4" << "=" << -30/3*21%4 << endl;

	return 0;
}
