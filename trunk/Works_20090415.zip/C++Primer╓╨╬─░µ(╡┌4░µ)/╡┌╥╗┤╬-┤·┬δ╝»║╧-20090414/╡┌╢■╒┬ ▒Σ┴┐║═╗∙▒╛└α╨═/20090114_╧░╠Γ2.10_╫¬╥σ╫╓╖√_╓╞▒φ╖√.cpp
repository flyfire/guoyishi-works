#include <iostream>

int main()
{
	std::cout << "\062" << "\t" << "\115" << "\n";

	return 0;
}