#include <iostream>

int main()
{
	std::cout << "None" "\t"
		<< "\?" 
		<< "\\"
		<< "\""
		<< 
		" None!!! ";
	std::cout << std::endl;
	std::cout 
		<<"n"<< "OK!\n";
	
	return 0;
}