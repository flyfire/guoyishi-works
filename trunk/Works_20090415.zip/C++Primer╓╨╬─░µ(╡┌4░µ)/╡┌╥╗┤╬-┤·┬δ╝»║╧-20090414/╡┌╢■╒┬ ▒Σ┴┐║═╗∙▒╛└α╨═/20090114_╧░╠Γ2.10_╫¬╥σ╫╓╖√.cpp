#include <iostream>

int main()
{
	std::cout << "\062" << "\115" << "\n";

	return 0;
}