//20090414
#include <iostream>
using namespace std;

int main()
{
	char ch;
	cin >> noskipws;
	while (cin >> ch)
		cout << ch;

	cin >> skipws;

	return 0;
}