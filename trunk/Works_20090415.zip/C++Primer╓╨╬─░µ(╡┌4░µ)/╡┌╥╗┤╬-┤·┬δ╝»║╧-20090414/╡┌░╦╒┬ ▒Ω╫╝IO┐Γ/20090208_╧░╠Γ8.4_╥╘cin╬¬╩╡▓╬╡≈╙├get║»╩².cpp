#include "20090208_get.hpp"
#include <iostream>
using namespace std;

int main()
{
	double dval;

	get(cin);
	cin >> dval;
	cout << dval << endl;

	return 0;
}