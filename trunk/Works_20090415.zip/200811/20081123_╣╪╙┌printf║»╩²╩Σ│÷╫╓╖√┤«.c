#include <stdio.h>
void main(void)

{
	char str[]={"Od\tfas dfa 15221\n"};
	printf("%s",str);
}