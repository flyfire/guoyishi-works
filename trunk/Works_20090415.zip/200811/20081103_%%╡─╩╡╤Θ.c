#include <stdio.h>
void main()
{
	int a=2,b=10;
	printf("a=\\\\%   %d,b=%  %d",a,b);

}