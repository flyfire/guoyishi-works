#include <stdio.h>
int main()
{
	char name[14];
	int i;
	printf("Input name:");
	scanf("%s",name);
	printf("%s\n",name);
}