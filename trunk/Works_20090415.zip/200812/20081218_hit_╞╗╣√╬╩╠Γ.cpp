#include <iostream>

int main()
{
	int value,i=0;
	while(std::cin >> value)
		if()
}