#include <iostream>
using namespace std;

int main()
{
	int ival;
	while(cin >> ival && ival != 42)
		;

	return 0;
}