//
istream_iterator<int> cin_it(cin);
istream_iterator<int> end_of_stream;
vector<int> ivec(cin_it, end_of_stream);