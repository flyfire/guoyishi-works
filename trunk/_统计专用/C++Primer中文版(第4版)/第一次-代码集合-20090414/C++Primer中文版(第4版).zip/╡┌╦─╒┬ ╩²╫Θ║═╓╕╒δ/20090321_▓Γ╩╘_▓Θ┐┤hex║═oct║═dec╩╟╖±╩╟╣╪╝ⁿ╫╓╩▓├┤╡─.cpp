//20090321 They(hex oct dec) can be use as identifier
#include <iostream>
using namespace std;

int main()
{
	int hex = 12;
	double oct = 12.1;
	short dec = 24;
	
	cout << hex << " " << oct << " " << dec << endl;

	return 0;
}