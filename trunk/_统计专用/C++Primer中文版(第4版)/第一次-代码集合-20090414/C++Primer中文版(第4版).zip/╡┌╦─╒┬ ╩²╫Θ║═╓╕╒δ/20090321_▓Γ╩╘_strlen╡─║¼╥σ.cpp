#include <iostream>
#include <cstring>
using namespace std;

int main()
{
	const char *str = "12345";
	cout << "Length of \"" << str << "\"" << " is " << strlen(str) << endl;

	return 0;
}