#include <iostream>

int main()
{
	for(int i=10;i>=0;--i)
		std::cout << i << std::endl;
	return 0;
}