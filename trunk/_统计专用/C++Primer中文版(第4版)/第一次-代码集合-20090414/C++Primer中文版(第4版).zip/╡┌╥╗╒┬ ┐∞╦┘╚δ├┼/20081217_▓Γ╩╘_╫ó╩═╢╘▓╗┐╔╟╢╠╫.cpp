#include <iostream>
/*
 //meiyou
 /* */meiyou
 int v1,v2;
*/

int main()
{
	return 0;
}