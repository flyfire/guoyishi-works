#include <iostream>
#include <vector>
#include "20090216_example.hpp"

	double Example::rate = 6.5;
	//const int Example::vecSize;
	vector<double> Example::vec(vecSize);

int main()
{


	return 0;
}
