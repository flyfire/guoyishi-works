#include <iostream>

int main()
{
	std::cout << "I\
have \
	a \
		dream!\n";

	return 0;
}