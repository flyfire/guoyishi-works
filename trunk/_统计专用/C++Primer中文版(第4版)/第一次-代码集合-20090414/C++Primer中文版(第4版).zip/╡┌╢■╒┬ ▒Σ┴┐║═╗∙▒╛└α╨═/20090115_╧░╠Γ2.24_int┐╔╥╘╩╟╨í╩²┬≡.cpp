#include <iostream>

int main()
{
	int val=1.01;
	std::cout << val << std::endl;

	return 0;
}