#include <iostream>
#include <string>
using namespace std;

int main()
{
	string s1,s2,s3;
	cout << "Is \"s1\" is empty ?"
		<< s1.empty() << endl;

	return 0;
}