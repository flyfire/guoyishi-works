#include <iostream>

class Foo
{
	//Empty
};

int main()
{
	return 0;
}

