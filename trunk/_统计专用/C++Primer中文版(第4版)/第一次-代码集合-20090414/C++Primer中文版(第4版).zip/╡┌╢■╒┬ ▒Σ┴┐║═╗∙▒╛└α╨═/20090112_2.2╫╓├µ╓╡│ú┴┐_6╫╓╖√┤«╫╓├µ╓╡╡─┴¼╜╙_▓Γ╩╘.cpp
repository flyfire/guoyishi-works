#include <iostream>

int main()
{
	std::cout << "Multi-line " L"literal" << std::endl;	//wrong
	return 0;
}