class Person {
private:
	std::string name;
	std::string address;
};