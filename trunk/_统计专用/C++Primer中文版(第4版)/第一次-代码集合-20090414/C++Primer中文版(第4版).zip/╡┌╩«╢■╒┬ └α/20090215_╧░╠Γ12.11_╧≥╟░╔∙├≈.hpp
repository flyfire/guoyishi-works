class Y;
class X {
private:
	Y *ptr;
}
class Y {
	X obj;
};