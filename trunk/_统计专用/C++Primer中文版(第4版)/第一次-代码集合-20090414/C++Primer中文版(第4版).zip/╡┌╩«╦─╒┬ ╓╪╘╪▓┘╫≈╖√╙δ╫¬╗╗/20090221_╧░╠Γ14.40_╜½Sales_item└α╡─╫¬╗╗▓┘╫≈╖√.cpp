Sales_item::operator string() const
{
	return isbn;
}

Sales_item::operator double() const
{
	return revenue;
}