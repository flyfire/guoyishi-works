//No.1
void error(const string &s, int index, int upperBound)
{
	cout << s << "Index is " << index
		<< " and upperBound is " << upperBound << endl;
}

//No.2
void error(const string &s)
{
	cout << s << endl;
}

//No.3
void error(const string &s, char selectVal)
{
	cout << s << ": " << selectVal << endl;
}